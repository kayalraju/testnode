

<script>

    console.log('app.js');
</script>